const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('limpar')
        .setDescription('Apaga mensagens do chat atual.')
        .addIntegerOption(option => 
            option.setName('quantidade')
                .setDescription('Quantas mensagens apagar (se não informar nada, apagará o canal inteiro!)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages), // Só aparece para quem tem permissão de gerenciar mensagens

    async execute(interaction) {
        // Bloqueio de segurança
        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return interaction.reply({ content: '❌ Você não tem permissão para gerenciar mensagens.', ephemeral: true });
        }

        const quantidade = interaction.options.getInteger('quantidade');
        const channel = interaction.channel;

        // Se NÃO passou a quantidade, fazemos o NUKE (apagar e recriar o canal inteiro)
        if (!quantidade) {
            await interaction.reply({ content: '⚠️ Iniciando o protocolo de limpeza total (Nuke) no canal...', ephemeral: true });
            
            try {
                const posicao = channel.position;
                
                // Clona o canal idêntico
                const novoCanal = await channel.clone({
                    position: posicao
                });
                
                // Deleta o canal antigo
                await channel.delete();
                
                // Manda uma mensagem de sucesso no canal novo
                await novoCanal.send('🧹 **Chat limpo com sucesso!** Todas as mensagens anteriores foram apagadas.');
            } catch (error) {
                console.error('[Nuke Error]', error);
                // Se der erro ao clonar, manda msg efêmera (mas o canal antigo ainda existe se falhou antes do delete)
                await interaction.followUp({ content: 'Houve um erro ao tentar limpar totalmente o canal. Verifique as permissões do bot.', ephemeral: true });
            }
            return;
        }

        // Se PASSOU a quantidade, usa o bulkDelete
        if (quantidade < 1 || quantidade > 100) {
            return interaction.reply({ content: '❌ Por favor, informe um número entre 1 e 100, ou deixe em branco para apagar tudo.', ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            const deleted = await channel.bulkDelete(quantidade, true);
            await interaction.editReply({ content: `✅ Limpeza concluída! Foram apagadas **${deleted.size}** mensagens.` });
        } catch (error) {
            console.error('[Comando Limpar]', error);
            await interaction.editReply({ content: 'Houve um erro ao apagar as mensagens. Lembre-se que o Discord não permite apagar mensagens com mais de 14 dias em massa.' });
        }
    },

    async executeMessage(message, args) {
        // Bloqueio de segurança
        if (!message.member.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return message.reply('❌ Você não tem permissão para gerenciar mensagens.');
        }

        const channel = message.channel;
        const quantidadeArg = args[0];

        // Se NÃO passou a quantidade, fazemos o NUKE
        if (!quantidadeArg || isNaN(quantidadeArg)) {
            try {
                const posicao = channel.position;
                
                // Clona o canal idêntico
                const novoCanal = await channel.clone({
                    position: posicao
                });
                
                // Deleta o canal antigo
                await channel.delete();
                
                // Manda uma mensagem de sucesso no canal novo
                await novoCanal.send('🧹 **Chat limpo com sucesso!** Todas as mensagens anteriores foram apagadas.');
            } catch (error) {
                console.error('[Nuke Error]', error);
                await message.reply('Houve um erro ao tentar limpar totalmente o canal. Verifique as permissões do bot.');
            }
            return;
        }

        const quantidade = parseInt(quantidadeArg);

        if (quantidade < 1 || quantidade > 100) {
            return message.reply('❌ Por favor, informe um número entre 1 e 100 (Exemplo: `biz!limpar 50`), ou deixe vazio (`biz!limpar`) para apagar tudo.');
        }

        try {
            // Se foi por comando, apaga a própria mensagem do comando primeiro pra não contar no limite
            if (message.deletable) {
                await message.delete().catch(() => {});
            }

            const deleted = await channel.bulkDelete(quantidade, true);
            
            const replyMsg = await channel.send(`✅ Limpeza concluída! Foram apagadas **${deleted.size}** mensagens.`);
            
            // Apaga a mensagem de confirmação após 5 segundos
            setTimeout(() => {
                replyMsg.delete().catch(() => {});
            }, 5000);

        } catch (error) {
            console.error('[Comando Limpar]', error);
            await message.reply('Houve um erro ao apagar as mensagens. Lembre-se que o Discord não permite apagar mensagens com mais de 14 dias em massa.');
        }
    }
};
