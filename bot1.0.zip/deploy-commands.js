const { REST, Routes } = require('discord.js');
require('dotenv').config();
const fs = require('fs');
const path = require('path');

const commands = [];
// Puxa todos os arquivos de comando da pasta commands
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
    const filePath = path.join(commandsPath, file);
    const command = require(filePath);
    if ('data' in command && 'execute' in command) {
        commands.push(command.data.toJSON());
    } else {
        console.log(`[AVISO] O comando em ${filePath} está faltando a propriedade "data" ou "execute".`);
    }
}

// Constrói o módulo REST com o token
const rest = new REST().setToken(process.env.DISCORD_TOKEN);

// Faz o deploy dos comandos
(async () => {
    try {
        console.log(`Começando a atualizar ${commands.length} slash commands.`);

        // Método put sobrescreve todos os comandos globalmente
        const data = await rest.put(
            Routes.applicationCommands(process.env.CLIENT_ID),
            { body: commands },
        );

        console.log(`Sucesso ao carregar ${data.length} slash commands.`);
    } catch (error) {
        console.error(error);
    }
})();
